#include "Bibliotheque.h"
#include "Document.h"
#include "Livre.h"
#include <iostream>
#include<vector>
using namespace std;

void Bibliotheque::ajouterDocument(Document *document){
    this->documents.push_back(document);
    cout << "Le document " << document->getTitre() << "a été ajouté avec succéss" << endl;
}
void Bibliotheque::supprimerDocument(Document *document){
    for(int i = 0 ; i < this->documents.size(); i++){
        if(document->getTitre() == this->documents[i]->getTitre()){
            documents.erase(documents.begin() + i);
            cout << "le document a été supprimé avec succès " << endl;
            exit;
        }

    }
}
void Bibliotheque::afficherDocuments(){
    for(Document *doc : this->documents ){
        doc->afficher();
    }
}
Document* Bibliotheque::chercher(string titre){
    for(Document *doc: this->documents){
        if(doc->getTitre() == titre){
            return doc;
        }
    }
    cout << "Aucun document trouvé" << endl;
    return NULL;
}

Document *Bibliotheque::chercher(int annee){
    for(Document *doc : this->documents){
        if(doc -> getAnnee() == annee){
            cout << "Le livre a été trouver " << endl;
            return doc;
        }
    }
    cout << "Aucun document n'a pas été trouvé : " << endl;
    return NULL;
}
void Bibliotheque::emprunter(string titre){
   Document *doc = chercher(titre);
   if(doc == NULL){
    cout << "Aucun document est disponible" << endl;
    exit;
   }
   doc->emprunter();
}
void Bibliotheque::rendre(string titre){
    Document *doc = chercher(titre);
    doc -> rendre();
    cout << "Le livre a été rendu avec succèss" << endl;
}
void Bibliotheque::sauvegarder(Document doc){

}
void Bibliotheque::charger(){
            
}

void Bibliotheque::menu(){
    cout << "================ Bibliothèque =================" << endl;
    cout << endl;
    cout << "1. Ajouter un document" << endl;
    cout << endl;
    cout << "2. Afficher" << endl;
    cout << endl;
    cout << "3. Chercher" << endl;
    cout << endl;
    cout << "4. Emprunter" << endl;
    cout << endl;
    cout << "5. Rendre" << endl;
    cout << endl;
    cout << "6. Supprimer" << endl;
    cout << endl;
    cout << "7. Sauvegarder" << endl;
    cout << endl;
    cout << "8.Charger" << end;
    cout << endl;
    cout << "0. Quitter" << endl;
    cout << endl;
    cout << "Votre choix : " << endl;
    int choix;
    cin >> choix;
    while(choix != 0){
        switch(choix){
            case 1 : this->ajouterDocument();break;
            case 2 : this->afficher();break;
            case 3 : this->Charger();break;
            case 4 : this->emprunter();break;
            case 5 : this->rendre();break;
            case 6 : this->supprimerDocument();break;
            case 7 : this->Sauvegarder();break;
            case 8 : break;
            default : cout << "Choix invalide "<<endl;
        }
    }
}