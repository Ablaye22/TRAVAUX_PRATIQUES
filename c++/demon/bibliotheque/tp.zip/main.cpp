#include<iostream>
#include "Magazine.h"
#include "Roman.h"
#include "Livre.h"
#include "Document.h"
#include "Bibliotheque.h"
using namespace std;


int main(){
    cout << "Bienvenu dans le Bibliotheque Edgar Morin" << endl;
    Roman *roman1 = new Roman("Amour Impossible","Victor Hugo",1823,"Amour");
    Roman *roman2 = new Roman("Les contemplation","Victor Hugo",1880,"Fiction");
    Livre *livre1 = new Livre("Le petit prince","Antoine de Saint Exepery",1846);
    Livre *livre2 = new Livre("Nini la mulatresse du senegal","Abdoulage Sadji",1920);
    Magazine *magazine1 = new Magazine("Le moment venu","Parletant",2000,1);
    Magazine *magazine2 = new Magazine("La revolution du numerique","Bill Gates",1983,2 );
    Bibliotheque *bu = new Bibliotheque();
    bu->ajouterDocument(roman1);
    bu->ajouterDocument(roman2);
    bu->ajouterDocument(livre1);
    bu->ajouterDocument(livre2);
    bu->ajouterDocument(magazine1);
    bu->ajouterDocument(magazine2);

    bu->afficherDocuments();


    delete roman1;
    delete roman2;
    delete livre1;
    delete livre2;
    delete magazine1;
    delete magazine2;
    delete bu;
    return 0;   
}