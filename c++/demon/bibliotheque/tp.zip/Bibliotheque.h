#ifndef BIBLIOTHEQUE_H
#define BIBLIOTHEQUE_H
#include"Document.h"
#include<iostream>
#include<vector>
using namespace std;

class Bibliotheque{
    vector<Document*> documents;
    public:
        void ajouterDocument(Document *document);
        void supprimerDocument(Document *document);
        void afficherDocuments();
        Document *chercher(string titre);
        //Document * chercher(string auteur);
        Document *chercher(int annee);
        void emprunter(string titre);
        void rendre(string titre);
        void sauvegarder(Document doc);
        void charger();
        void menu();
};

#endif